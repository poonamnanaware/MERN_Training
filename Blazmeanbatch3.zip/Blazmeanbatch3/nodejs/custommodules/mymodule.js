// The exported module
module.exports = {
    add: function(x,y) {
        return x + y;
    },
    pow: function(x,y) {
        return Math.pow(x,y);
    }
};