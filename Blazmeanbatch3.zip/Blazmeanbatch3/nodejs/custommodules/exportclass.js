class MyClass {
    sort(arr){
        return arr.sort();
    }
}
// exporting class
module.exports = MyClass;