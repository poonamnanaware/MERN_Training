// a regular JavaSCript function Syntax

// function w/o input and output parameter
function doWork(){
    console.log('The Do Work Function');
}

// calling the function
doWork();

// function with input parameters
function addValues(x,y){
    let z = x + y;
    console.log('z = ' + z);
}

// function with input and output parameters
function addData(x,y){
    return x + y;
}


