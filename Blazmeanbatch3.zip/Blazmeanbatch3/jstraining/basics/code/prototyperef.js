// a seperate file that will contain an additional logic 
// for MyObject from referencefunction.js

MyObject.prototype.div = function (x, y) {
  //  if (MyObject.privateValidator(x, y) == 0) return 0;
    return x / y;
}