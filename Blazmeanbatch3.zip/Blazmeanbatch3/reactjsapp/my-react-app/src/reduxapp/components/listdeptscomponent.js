import {useState} from 'react';
import {useDispatch} from 'react-redux';
import DataGridComponent from './../../components/reusablecomponents/datagridcomponent';
import selectDepartment from './../actions/action2.js';

const ListDepartmentsComponent=(props)=>{

    let dispatch = useDispatch();

    const getRow=(dept)=>{

        console.log('-----------------');

        dispatch(selectDepartment(dept));

    };

    let dataSource = [];

    for (const record of props.departments) {
        dataSource.push(record.department);    
    }

    
    return(
        <div className="container">
            <h1>List of Departments</h1>
           
            <DataGridComponent dataSource={dataSource} getSelectedRow={getRow}></DataGridComponent>
            
        </div>
    );
};

export default ListDepartmentsComponent;