
function OtherComponent(props){
    return (
        <div>
            <h2>Some Other Component</h2>
            <strong>
                {props.value}
            </strong>
        </div>
    );
}

export default OtherComponent;
