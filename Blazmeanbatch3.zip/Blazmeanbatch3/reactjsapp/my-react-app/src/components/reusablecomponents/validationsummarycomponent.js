

import { useContext } from 'react';
import { DataContext } from './../datacontext';

const ValidationSummaryComponent = () => {

    let dataSource = useContext(DataContext);

    if (dataSource === undefined || dataSource.length === 0) {
        return (
            <div className="container">
                <strong>
                    No records to display
                </strong>
            </div>
        );
    } else {
      
        var validationSummary = dataSource.validationSummary;
        var isFormValid = dataSource.isFormValid;


        for (let i = 0; i < validationSummary.length; i++) {
            if (validationSummary.length > 1) {
                validationSummary = validationSummary.splice(1);

            }
        }

        console.log(`${JSON.stringify(validationSummary)}`);
        return (

            <div className="alert alert-danger" hidden={isFormValid}>
                {JSON.stringify(validationSummary)}
            </div>
        );

    }


};

export default ValidationSummaryComponent;