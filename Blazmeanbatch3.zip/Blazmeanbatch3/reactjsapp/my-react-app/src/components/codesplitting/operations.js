export class StringOperations {
    getLength(str){
        return str.length;
    }
    changeCase(str){
        return str.toUpperCase();
    }
}