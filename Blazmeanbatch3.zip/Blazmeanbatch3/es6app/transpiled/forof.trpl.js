"use strict";

var names = ["James Bond", "Ethan Hunt", "Jason Bourn", "Indiana Jones", "Jack Reacher", "Jack Stepalton"];

for (var _i = 0, _names = names; _i < _names.length; _i++) {
  var n = _names[_i];
  console.log("Name =  ".concat(n));
}
