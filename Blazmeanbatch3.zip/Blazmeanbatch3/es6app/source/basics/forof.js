let names = ["James Bond", "Ethan Hunt", "Jason Bourn", "Indiana Jones", "Jack Reacher", "Jack Stepalton"];
// Each n read and processed and then goes to next n in sequence
for(let n of names){
    console.log(`Name =  ${n}`);
}