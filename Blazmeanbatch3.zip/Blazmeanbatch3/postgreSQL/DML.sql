Select * from Department;

Insert into Department Values (30, 'SL', 'Banguluru', 56); 
Insert into Department Values (40, 'TR', 'Pune', 35); 
Insert into Department Values (50, 'AD', 'Pune', 15); 

Insert into Employee Values (101, 'Mahesh', 'Manager', 100000,10);
Insert into Employee Values (102, 'Tejas', 'Lead', 100000,20);
Insert into Employee Values (103, 'Remesh', 'Manager', 100000,30);
Insert into Employee Values (104, 'Ram', 'Manager', 100000,40);
Insert into Employee Values (105, 'Leena', 'Manager', 100000,50);
Insert into Employee Values (106, 'Neeta', 'Lead', 90000,10);
Insert into Employee Values (107, 'Shweta', 'Lead', 90000,20);
Insert into Employee Values (108, 'Aparna', 'Lead', 90000,30);
Insert into Employee Values (109, 'Chaitanya', 'Lead', 90000,40);
Insert into Employee Values (110, 'Kapil', 'Lead', 90000,50);
Insert into Employee Values (111, 'Amit', 'Engineer', 70000,10);
Insert into Employee Values (112, 'Abhijit', 'Engineer', 70000,20);
Insert into Employee Values (113, 'Ajit', 'Engineer', 70000,30);
Insert into Employee Values (114, 'Mayuresh', 'Engineer', 70000,40);
Insert into Employee Values (115, 'Nandu', 'Engineer', 70000,50);
Insert into Employee Values (116, 'Anil', 'Programmer', 60000,10);
Insert into Employee Values (117, 'Abhay', 'Programmer', 60000,20);
Insert into Employee Values (118, 'Jaywant', 'Programmer', 60000,30);
Insert into Employee Values (119, 'Anil', 'Programmer', 60000,40);
Insert into Employee Values (120, 'Shyam', 'Programmer', 60000,50);
Insert into Employee Values (121, 'Sidh', 'Programmer', 21143,50);


select * from Employee;