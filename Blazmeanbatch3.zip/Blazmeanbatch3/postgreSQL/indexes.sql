Create Index EmpNo_Index
on Employee (EmpNo);