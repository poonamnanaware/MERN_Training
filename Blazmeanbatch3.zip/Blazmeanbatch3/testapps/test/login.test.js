import test from 'chai';
import request from 'request';

// the assertion object that will be used to compare the expected result withe actual 

let expect = test.expect; 

import instance from './../server.js';

// The test data
let data = [
    {id:1,name:'A'},
    {id:2,name:'B'}
];

describe('REST APT Test',()=>{

    it('User should be able to login',(done)=>{
        let postedData = {
            "username":"Poonam",
            "password": "poonam"
        };
        request.post('http://localhost:7015/api/auth/authuser', {
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(postedData)
        },(error,response,body)=>{
            expect(response.statusCode).to.equal(200);
            done();    
        });
        
    });
});