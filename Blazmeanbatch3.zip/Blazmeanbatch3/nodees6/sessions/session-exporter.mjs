// .mjs is an extension used for types in node.js those who are not exporting the default
// IMP***: Please make sure ES6 package from https://www.npmjs.com is property installed
import session from 'express-session'
// Exported as ES 6 object
export default session;